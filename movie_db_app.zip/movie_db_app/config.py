# config.py
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '', #change it with your password
    'database': 'MovieDB'
}
